import java.awt.Color;
import java.util.ArrayList;

public class KdTree implements PointContainer
{
	private int size;
	private Node root;
	
	public KdTree() {
		this.size = 0;
		this.root = null;
	}
	
	private class Node {
		private Point2D value;
		private RectHV rect;
		
		private Node left;
		private Node right;
		
		public Node(Point2D value, RectHV rect) {
			this.value = value;
			this.rect = rect;
		}
	}
	
    public boolean isEmpty() {
    	return this.size == 0;
    }
    
    public int size() {
    	return this.size;
    }
    
    public void insert(Point2D p) {
    	if (p == null) {
    		throw new NullPointerException();
    	}
    	
    	if (this.root == null) {
    		this.root = new Node(p, new RectHV(0, 0, 1, 1));
    		this.size++;
    	} else {
    		this.insertCheckX(this.root, p);
    	}
    }
    
    private void insertCheckX(Node node, Point2D p) {
    	if (p.x() < node.value.x()) {
    		if (node.left == null) {
    			node.left = new Node(p, new RectHV(node.rect.xmin(), node.rect.ymin(), node.value.x(), node.rect.ymax()));
    			this.size++;
    		} else {
    			this.insertCheckY(node.left, p);
    		}
    	} else if (node.value.x() == p.x() && node.value.y() == p.y()) {
    		return;
    	} else {
    		if (node.right == null) {
    			node.right = new Node(p, new RectHV(node.value.x(), node.rect.ymin(), node.rect.xmax(), node.rect.ymax()));
    			this.size++;
    		} else {
    			this.insertCheckY(node.right, p);
    		}
    	}
    }
    
    private void insertCheckY(Node node, Point2D p) {
    	if (p.y() < node.value.y()) {
    		if (node.left == null) {
    			node.left = new Node(p, new RectHV(node.rect.xmin(), node.rect.ymin(), node.rect.xmax(), node.value.y()));
    			this.size++;
    		} else {
    			this.insertCheckX(node.left, p);
    		}
    	} else if (node.value.x() == p.x() && node.value.y() == p.y()) {
    		return;
    	} else {
    		if (node.right == null) {
    			node.right = new Node(p, new RectHV(node.rect.xmin(), node.value.y(), node.rect.xmax(), node.rect.ymax()));
    			this.size++;
    		} else {
    			this.insertCheckX(node.right, p);
    		}
    	}
    }
    
    public boolean contains(Point2D p) {
    	if (p == null) {
    		throw new NullPointerException();
    	}
    	
    	return this.containsCheckX(this.root, p);
    }
    
    private boolean containsCheckX(Node node, Point2D p) {
    	if (node == null) {
    		return false;
    	}
    	
    	if (p.x() < node.value.x()) {
    		return this.containsCheckY(node.left, p);
    	} else if (p.y() == node.value.y() && p.x() == node.value.x()) {
    		return true;
    	} else {
    		return this.containsCheckY(node.right, p);
    	}
    }
    
    private boolean containsCheckY(Node node, Point2D p) {
    	if (node == null) {
    		return false;
    	}
    	
    	if (p.y() < node.value.y()) {
    		return this.containsCheckX(node.left, p);
    	} else if (p.y() == node.value.y() && p.x() == node.value.x()) {
    		return true;
    	} else {
    		return this.containsCheckX(node.right, p);
    	}
    }

    public void draw(Canvas canvas) {
    	canvas.setPenRadius(0.01);
    	canvas.setPenColor(Color.BLACK);
    	canvas.point(this.root.value.x(), this.root.value.y());
    	
    	canvas.setPenRadius(0.002);
    	canvas.setPenColor(Color.RED);
    	canvas.line(this.root.value.x(), 0, this.root.value.x(), 1);
    	
    	this.drawCheckX(this.root, canvas);
    }
    
    private void drawCheckX(Node node, Canvas canvas) {
    	if (node.left != null) {
    		canvas.setPenRadius(0.01);
        	canvas.setPenColor(Color.BLACK);
        	canvas.point(node.left.value.x(), node.left.value.y());
        	
        	canvas.setPenRadius(0.002);
        	canvas.setPenColor(Color.BLUE);
        	canvas.line(node.rect.xmin(), node.left.value.y(), node.value.x(), node.left.value.y());
        	
        	this.drawCheckY(node.left, canvas);
    	}
    	
    	if (node.right != null) {
    		canvas.setPenRadius(0.01);
        	canvas.setPenColor(Color.BLACK);
        	canvas.point(node.right.value.x(), node.right.value.y());
        	
        	canvas.setPenRadius(0.002);
        	canvas.setPenColor(Color.BLUE);
        	canvas.line(node.value.x(), node.right.value.y(), node.rect.xmax(), node.right.value.y());
        	
        	this.drawCheckY(node.right, canvas);
    	}
    }
    
    private void drawCheckY(Node node, Canvas canvas) {
    	if (node.left != null) {
    		canvas.setPenRadius(0.01);
        	canvas.setPenColor(Color.BLACK);
        	canvas.point(node.left.value.x(), node.left.value.y());
        	
        	canvas.setPenRadius(0.002);
        	canvas.setPenColor(Color.RED);
        	canvas.line(node.left.value.x(), node.rect.ymin(), node.left.value.x(), node.value.y());
        	
        	this.drawCheckX(node.left, canvas);
    	}
    	
    	if (node.right != null) {
    		canvas.setPenRadius(0.01);
        	canvas.setPenColor(Color.BLACK);
        	canvas.point(node.right.value.x(), node.right.value.y());
        	
        	canvas.setPenRadius(0.002);
        	canvas.setPenColor(Color.RED);
        	canvas.line(node.right.value.x(), node.value.y(), node.right.value.x(), node.rect.ymax());
        	
        	this.drawCheckX(node.right, canvas);
    	}
    }
    
    public Iterable<Point2D> range(RectHV rect) {
    	if (rect == null) {
    		throw new NullPointerException();
    	}
    	
    	return this.range(this.root, rect, new ArrayList<Point2D>());
    }
    
    private Iterable<Point2D> range(Node node, RectHV rect, ArrayList<Point2D> list) {
    	if (node == null) {
    		return list;
    	}
    	
    	if (!node.rect.intersects(rect)) {
    		return list;
    	}
    	
    	if (rect.contains(node.value)) {
    		list.add(node.value);
    	}
    	
    		this.range(node.left, rect, list);
    		this.range(node.right, rect, list);
    	
    	return list;
    }
    
    public Point2D nearest(Point2D p) {
    	if (p == null) {
    		throw new NullPointerException();
    	}
    	
    	if (this.isEmpty()) {
    		return null;
    	}
    	
    	return this.nearestCheckX(this.root, p, this.root.value);
    }
    
    private Point2D nearestCheckX(Node node, Point2D p, Point2D currentClosest) {
    	if (node == null) {
    		return currentClosest;
    	} else if (p.distanceSquaredTo(currentClosest) < node.rect.distanceSquaredTo(p)) {//Quit if the distance to the rectangle is too large
    		return currentClosest;
    	} else if (p.distanceSquaredTo(currentClosest) > p.distanceSquaredTo(node.value)) {
			currentClosest = node.value;
		}
    	
    	Point2D closest1;
    	Point2D closest2;
    	
    	if (p.x() < node.value.x()) {
    		closest1 = nearestCheckY(node.left, p, currentClosest);
    		
    		if (currentClosest.distanceSquaredTo(p) > closest1.distanceSquaredTo(p)) {
        		currentClosest = closest1;
        	}
    		
    		closest2 = nearestCheckY(node.right, p, currentClosest);
    	} else {
    		closest1 = nearestCheckY(node.right, p, currentClosest);
    		
    		if (currentClosest.distanceSquaredTo(p) > closest1.distanceSquaredTo(p)) {
        		currentClosest = closest1;
        	}
    		
    		closest2 = nearestCheckY(node.left, p, currentClosest);
    	}
    	
    	
    	
    	if (currentClosest.distanceSquaredTo(p) > closest2.distanceSquaredTo(p)) {
    		currentClosest = closest2;
    	}
    	
    	return currentClosest;
    }
    
    private Point2D nearestCheckY(Node node, Point2D p, Point2D currentClosest) {
    	if (node == null) {
    		return currentClosest;
    	} else if (p.distanceSquaredTo(currentClosest) < node.rect.distanceSquaredTo(p)) {//Quit if the distance to the rectangle is too large
    		return currentClosest;
    	} else if (p.distanceSquaredTo(currentClosest) > p.distanceSquaredTo(node.value)) {
			currentClosest = node.value;
		}
    	
    	Point2D closest1;
    	Point2D closest2;
    	
    	if (p.y() < node.value.y()) {
    		closest1 = nearestCheckX(node.left, p, currentClosest);
    		
    		if (currentClosest.distanceSquaredTo(p) > closest1.distanceSquaredTo(p)) {
        		currentClosest = closest1;
        	}
    		
    		closest2 = nearestCheckX(node.right, p, currentClosest);
    	} else {
    		closest1 = nearestCheckX(node.right, p, currentClosest);
    		
    		if (currentClosest.distanceSquaredTo(p) > closest1.distanceSquaredTo(p)) {
        		currentClosest = closest1;
        	}
    		
    		closest2 = nearestCheckX(node.left, p, currentClosest);
    	}
    	
    	
    	
    	if (currentClosest.distanceSquaredTo(p) > closest2.distanceSquaredTo(p)) {
    		currentClosest = closest2;
    	}
    	
    	return currentClosest;
    }
    
}