import java.awt.Color;

public class PointSET implements PointContainer
{    
    private SET<Point2D> set;
	public PointSET(){
		set = new SET<Point2D>();
	}
	
	public boolean isEmpty()
    {
        return set.isEmpty();
    }
    
    public int size()
    {
        return set.size();

    }
    
    public void insert(Point2D p)
    {
    	set.add(p);
    }
    
    public boolean contains(Point2D p)
    {
        return set.contains(p);
    }
    
    public void draw(Canvas canvas)
    {
        canvas.setPenColor(Color.BLACK);
        canvas.setPenRadius(.01);
        
        // TODO: Insert code here to call the point() method on canvas
        // for each point that has been inserted into your PointSET
        for (Point2D point : set){
        	canvas.point(point.x(), point.y());
        }
        // Don't forget to remove this!
    	
    }
    
    public Iterable<Point2D> range(RectHV rect)
    {
    	if (rect == null){
    		throw new java.lang.NullPointerException();
    	}
    	SET<Point2D> pointRange = new SET<Point2D>();
    	for (Point2D point : set){
    		if (rect.contains(point)){
    			pointRange.add(point);
    		}
    	}
    	return pointRange;
    }
    
    public Point2D nearest(Point2D p)
    {
    	if (set.isEmpty() == true){
    		return null;
    	}
    	if (p == null){
    		throw new java.lang.NullPointerException();
    	}
    	Point2D pointWinner = null;
    	double distanceWinner = 1000000000.0;
    	for (Point2D point : set){
    		double distance = p.distanceTo(point);
    		//check to see if the current distance is closer than the previous proximity winner
    		if (distance < distanceWinner){
    			distanceWinner = distance;
    			pointWinner = point;
    		}
    	}
    	return pointWinner;
    }
}