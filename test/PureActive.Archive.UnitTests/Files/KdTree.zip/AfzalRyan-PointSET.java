import java.awt.Color;
import java.util.TreeSet;

public class PointSET implements PointContainer
{    
	private TreeSet<Point2D> set;
	
	public PointSET() {
		this.set = new TreeSet<Point2D>();
	}
	
    public boolean isEmpty() {
        return this.set.isEmpty();
    }
    
    public int size() {
    	return this.set.size();
    }
    
    public void insert(Point2D p) {
    	if (p == null) {
    		throw new NullPointerException();
    	}
    	
        this.set.add(p);
    }
    
    public boolean contains(Point2D p) {
    	if (p == null) {
    		throw new NullPointerException();
    	}
    	
    	return this.set.contains(p);
    }
    
    public void draw(Canvas canvas) {
    	if (canvas == null) {
    		throw new NullPointerException();
    	}
    	
        canvas.setPenColor(Color.BLACK);
        canvas.setPenRadius(.01);
        
        for (Point2D p : this.set) {
        	canvas.point(p.x(), p.y());
        }
    }
    
    public Iterable<Point2D> range(RectHV rect) {
    	if (rect == null) {
    		throw new NullPointerException();
    	}
    	
    	TreeSet<Point2D> set = new TreeSet<Point2D>();
    	
    	for (Point2D point : this.set) {
    		if (((point.x() >= rect.xmin()) && (point.x() <= rect.xmax())) && ((point.y() >= rect.ymin()) && (point.y() <= rect.ymax()))) {
    			set.add(point);
    		}
    	}
    	
    	return set;
    }
    
    public Point2D nearest(Point2D p) {
    	if (p == null) {
    		throw new NullPointerException();
    	}
    	
    	Point2D output = null;
    	
    	for (Point2D pointToCompare : this.set) {
    		if (output == null || p.distanceTo(output) > p.distanceTo(pointToCompare)) {
    			output = pointToCompare;
    		}
    	}
    	
    	return output;
    }
}