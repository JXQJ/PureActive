import java.awt.Color;

//import BSTSymbolTable.Node;

public class KdTree implements PointContainer
{
    
	private static class Node
	{
	    private Point2D p;      // the point
	    private RectHV rect;    // the axis-aligned rectangle
	                            // corresponding to this node (Ignore for now)
	    private Node lb;        // the left/bottom subtree
	    private Node rt;        // the right/top subtree
	    
	    private Node(Point2D p, RectHV rect){
	    	this.p = p;
	    	this.rect = rect;
	    	this.lb = null;
	    	this.rt = null;
	    }	    
	}
	
	
	private Node root;
	private int size;

	
	public KdTree(){
		size = 0;
		root = null;

	}
	public boolean isEmpty()
    {
    	if (root == null){
    		return true;
    	}
    	return false;
    }
    
    public int size()
    {
    	return size;
    }
    
    public void insert(Point2D p)
    {
    	if (p == null){
    		throw new java.lang.NullPointerException();
    	}
    	else if (find(root, p, 0)){
    		return;
    	} else {
    		size++;
	    	Node node = new Node(p,null);
	    	if (isEmpty()){
	    		root = node;
	    		node.rect = new RectHV(0,0,1,1);
	    	} else {
	    		insert(root, node, p, 0);
	    		
	    	}
    	}
    } 
    
    private void insert(Node current, Node newNode, Point2D p, int level){
    	if (level % 2 == 0){
    		if (newNode.p.x() < current.p.x()){
    			if (current.lb == null){
    				current.lb = newNode;
    				current.lb.rect = new RectHV(current.rect.xmin(), current.rect.ymin(), current.p.x(), current.rect.ymax());
    			} else {
    				insert(current.lb, newNode, p, level+1);
    			}
    		} else {
    			if (current.rt == null){
    				current.rt = newNode;
    				current.rt.rect = new RectHV(current.p.x(), current.rect.ymin(), current.rect.xmax(), current.rect.ymax());
    			} else {
    				insert(current.rt, newNode, p, level+1);
    			}
    		}	
    	} else {
    		if ((newNode.p.y() < current.p.y())){
    			if (current.lb == null){
    				current.lb = newNode;
    				current.lb.rect = new RectHV(current.rect.xmin(), current.rect.ymin(), current.rect.xmax(), current.p.y());
    			} else {
    				insert(current.lb, newNode, p, level+1);
    			}
    		} else {
    			if (current.rt == null){
    				current.rt = newNode;
    				current.rt.rect = new RectHV(current.rect.xmin(), current.p.y(), current.rect.xmax(), current.rect.ymax());
    			} else {
    				insert(current.rt, newNode, p, level+1);
    			}
    		}
    		
    	}

    }
 
    public boolean contains(Point2D p)
    {
    	int level = 0;
    	return find(root, p, level);

    }
    
    private boolean find(Node current, Point2D point, int level){
    	if (current == null){
    		return false;
    	}
    	if (point == null){
    		throw new java.lang.NullPointerException();
    	}
    	else if (level % 2 == 0){
    		if (point.x() < (current.p.x())){
        		return find(current.lb, point, level+1);
        	} else {
        		if(current.p.equals(point)){
            		return true;
            	}
        		return find(current.rt, point, level+1);
        	}
    		
    	} else {
    		if (point.y() < (current.p.y())){
        		return find(current.lb, point, level+1);
        	} else {
        		if(current.p.equals(point)){
        			return true;
        		}
        			return find(current.rt, point, level + 1);
        	}
    	
    	}
    }

    public void draw(Canvas canvas)
    {
    	int level = 0;
    	draw(canvas, root, level);
    	// Use canvas to draw your points and dividing lines
    	//
    	// For points, use these calls:
        //    canvas.setPenRadius(.01);
    	//    canvas.setPenColor(Color.BLACK);
    	//    canvas.point(put your parameters here)
    	//
    	// For dividing lines, use these calls:
    	//    canvas.setPenRadius(.002);
    	//	  canvas.setPenColor(Color.RED); (for vertical dividing lines)
    	//	  canvas.setPenColor(Color.BLUE); (for horizontal dividing lines)
    	//    canvas.line(put your parameters here)


        // Don't forget to remove this!

    }
    
    private void draw(Canvas canvas, Node node, int level){
    	if (node != null){
    	
    		draw(canvas, node.lb, level+1);
    		canvas.setPenRadius(.002);
    		//for vertical lines
    		if (level % 2 == 0){
    			canvas.setPenColor(Color.RED);
    			canvas.line(node.p.x(), node.rect.ymin(), node.p.x(), node.rect.ymax());
    		//for horizontal lines
    		} else {
    			canvas.setPenColor(Color.BLUE);
    			canvas.line(node.rect.xmin(), node.p.y(), node.rect.xmax(), node.p.y());
    		}
    		canvas.setPenColor(Color.BLACK);
    		canvas.setPenRadius(.01);
    		canvas.point(node.p.x(), node.p.y());;
    		draw(canvas, node.rt, level+1);
    	}
    	
    }
    
    public Iterable<Point2D> range(RectHV rect)
    {
    	Queue<Point2D> q = new Queue<Point2D>();
    	range(root, rect, q);
    	return q;
    }      
    
    private void range(Node node, RectHV rect, Queue<Point2D> q){
    	if (node != null && rect.intersects(node.rect)){
    		if (rect.contains(node.p)){
    			q.enqueue(node.p);
    		}
    		range(node.lb, rect, q);
    		range(node.rt, rect, q);
    	}
    }
    public Point2D nearest(Point2D p)
    {
    	if (p == null){
    		throw new java.lang.NullPointerException();
    	}
    	if (isEmpty()){
    		return null;
    	}
    	return nearest(p, root.p, root, 0);
    }
    
    private Point2D nearest(Point2D p, Point2D closest, Node n, int level){
    	if (n == null){
    		return closest;
    	}
    	double distance = closest.distanceTo(p);
    	if (n.rect.distanceTo(p) < distance){
    		if (n.p.distanceTo(p) < distance){
    			closest = n.p;
    		}
    		if (level % 2 == 0){
    			// compare x values
    			if (p.x() < n.p.x()){
        			closest = nearest(p, closest, n.lb, level+1);
        			closest = nearest(p, closest, n.rt, level+1);
        		} else {
        			closest = nearest(p, closest, n.rt, level+1);
        			closest = nearest(p, closest, n.lb, level+1);
        		}
    		} else {
    			// compare y values
	    		if (p.y() < n.p.y()){
	    			closest = nearest(p, closest, n.lb, level+1);
	    			closest = nearest(p, closest, n.rt, level+1);
	    		} else {
	    			closest = nearest(p, closest, n.rt, level+1);
	    			closest = nearest(p, closest, n.lb, level+1);
	    		}
    		}
    	}
    	return closest;
    }
    
    public static void main(String[] args){
    	KdTree tree = new KdTree();
    	Point2D p1 = new Point2D(0.1,0.2);
    	tree.insert(p1);
    	Point2D p2 = new Point2D(0.2,0.3);
    	tree.insert(p2);
    	tree.insert(p2);
    	Point2D p3 = new Point2D(0.3,0.4);
    	tree.insert(p3);
    	Point2D p4 = new Point2D(0.4,0.5);
    	tree.insert(p4);
    	
    	Point2D p7 = new Point2D(0.4,0.4);
    	
    	Point2D p6 = new Point2D(0.4,0.3);

    	
    	Point2D p5 = new Point2D(0.9,0.9);
    	
    	System.out.println(tree.contains(p1) + "");
    	System.out.println(tree.contains(p5) + "");
    	System.out.println(tree.contains(p2) + "");
    	System.out.println(tree.contains(p6) + "");
    	System.out.println(tree.contains(p7) + "");
    }
}